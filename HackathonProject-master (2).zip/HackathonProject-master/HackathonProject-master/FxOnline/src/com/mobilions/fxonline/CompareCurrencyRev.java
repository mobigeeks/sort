package com.mobilions.fxonline;

import java.util.Comparator;

public class CompareCurrencyRev implements Comparator<TabRow>{

	@Override
	public int compare(TabRow t1, TabRow t2) {
	
		if(t1.cur.compareTo(t2.cur)<0)
			return 1;
		else if(t1.cur.compareTo(t2.cur)>0)
			return -1;
		else
			return 0;
	
		
	}

	
}
