package com.mobilions.fxonline;
import java.util.Comparator;

public class ComparePnl implements Comparator<TabRow>{

	public int compare(TabRow o1, TabRow o2) {
		if(o1.pnl>o2.pnl)
			return 1;
		else if(o1.pnl<o2.pnl)
			return -1;
		else

			
		return 0;
	}
	
}
