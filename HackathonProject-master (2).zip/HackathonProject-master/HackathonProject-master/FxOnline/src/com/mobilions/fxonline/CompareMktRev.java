package com.mobilions.fxonline;
import java.util.Comparator;

public class CompareMktRev implements Comparator<TabRow>{

	public int compare(TabRow o1, TabRow o2) {
		if(o1.mkt<o2.mkt)
			return 1;
		else if(o1.mkt>o2.mkt)
			return -1;
		else

			
		return 0;
	}
	
}
